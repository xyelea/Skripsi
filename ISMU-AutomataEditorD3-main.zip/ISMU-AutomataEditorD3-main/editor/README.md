# Editor

A web application created as a result of my bachelor thesis at IS MU for the course IB005 Formal languages and automata. The editor can be integrated into a ROPOT or any website. 

To locally test it out, open the file **editorWeb.html** (located in the LocalTesting folder) in any web browser.

## Languages
Localisation files for the editor.

## Parsers
This folder contains JavaScript files created by Radim Cebis used for syntax checking functionality of the editor.

## Libs
A folder containing JavaScript libraries necessary for the editor to function.