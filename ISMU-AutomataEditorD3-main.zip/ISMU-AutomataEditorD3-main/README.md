# ISMU-AutomataEditorD3

A finite automata editor created for the course IB005 Formal languages and automata at Masaryk University, Brno.
